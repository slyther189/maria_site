/* ============================================
   data.js — Placeholder
   Replace with your full buchhaus_paintings.json
   or load via fetch in gallery.js

   To use your JSON file directly:
   - Remove this file
   - Place buchhaus_paintings.json in the root folder
   - gallery.js will fetch it automatically

   OR keep this file and paste your full array here
   as: const PAINTINGS = [ ... ];
   ============================================ */

const PAINTINGS = [
  {
    "id": 1,
    "dateiname": "IMG_8364.jpeg",
    "titel": null,
    "farbe_de": ["braun","beige","ocker","dunkelbraun","grau","weinrot"],
    "farbe_en": ["brown","beige","ochre","dark brown","grey","wine red"],
    "motiv_de": ["Gesichter","Figuren","Gruppe","Kubismus","Porträt","abstrakt-figurativ"],
    "motiv_en": ["faces","figures","group","cubism","portrait","abstract-figurative"],
    "stimmung_de": ["rätselhaft","ernst","meditativ","fragmentiert","dicht"],
    "stimmung_en": ["enigmatic","serious","meditative","fragmented","dense"],
    "technik_de": ["Acryl","Leinwand","kubistisch"],
    "technik_en": ["acrylic","canvas","cubist"],
    "beschreibung_de": "Mehrere kubistisch zerlegte Gesichter und Figuren drängen sich auf dunklem Hintergrund zusammen. Geometrische Flächen in Braun, Ocker und Beige überlagern sich zu einem dichten, fast mosaikartigen Bild voller stiller Intensität.",
    "beschreibung_en": "Several cubist-fragmented faces and figures crowd together against a dark background."
  }
];
